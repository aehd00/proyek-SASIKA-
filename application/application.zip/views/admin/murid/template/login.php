<!-- stylesheet -->
<link href="<?= base_url() . 'assets/login/css/main.css' ?>" rel="stylesheet">
<link href="<?= base_url() . 'assets/login/css/util.css' ?>" rel="stylesheet">

<!-- font -->
<link href="<?= base_url() . 'assets/login/fonts/font-awesome-4.7.0/css/font-awesome.css' ?>" rel="stylesheet">
<link href="<?= base_url() . 'assets/login/fonts/font-awesome-4.7.0/css/font-awesome.min.css' ?>" rel="stylesheet">

<!-- animate -->
<link href="<?= base_url() . 'assets/login/vendor/animate/animate.css' ?>" rel="stylesheet">

<!-- bootstrap -->
<link href="<?= base_url() . 'assets/login/vendor/bootstrap/css/bootstrap.css' ?>" rel="stylesheet">
<link href="<?= base_url() . 'assets/login/vendor/bootstrap/css/bootstrap.min.css' ?>" rel="stylesheet">
<link href="<?= base_url() . 'assets/login/vendor/bootstrap/css/bootstrap-grid.css' ?>" rel="stylesheet">
<link href="<?= base_url() . 'assets/login/vendor/bootstrap/css/bootstrap-grid.min.css' ?>" rel="stylesheet">
<link href="<?= base_url() . 'assets/login/vendor/bootstrap/css/bootstrap-reboot.css' ?>" rel="stylesheet">
<link href="<?= base_url() . 'assets/login/vendor/bootstrap/css/bootstrap-reboot.min.css' ?>" rel="stylesheet">

<!-- bootstrap js-->
<link href="<?= base_url() . 'assets/login/vendor/bootstrap/js/bootstrap.js' ?>" rel="stylesheet">
<link href="<?= base_url() . 'assets/login/vendor/bootstrap/js/bootstrap.min.js' ?>" rel="stylesheet">
<link href="<?= base_url() . 'assets/login/vendor/bootstrap/js/popper.js' ?>" rel="stylesheet">
<link href="<?= base_url() . 'assets/login/vendor/bootstrap/js/popper.min.js' ?>" rel="stylesheet">
<link href="<?= base_url() . 'assets/login/vendor/bootstrap/js/tooltip.js' ?>" rel="stylesheet">

<!-- js -->
<link href="<?= base_url() . 'assets/login/js/main.js' ?>" rel="stylesheet">

<!-- animsition -->
<link href="<?= base_url() . 'assets/login/vendor/animsition/css/animsition.css' ?>" rel="stylesheet">
<link href="<?= base_url() . 'assets/login/vendor/animsition/css/animsition.min.css' ?>" rel="stylesheet">
<link href="<?= base_url() . 'assets/login/vendor/animsition/js/animsition.js' ?>" rel="stylesheet">
<link href="<?= base_url() . 'assets/login/vendor/animsition/js/animsition.min.js' ?>" rel="stylesheet">

<!-- countdowntime -->
<link href="<?= base_url() . 'assets/login/vendor/countdowntime/countdowntime.js' ?>" rel="stylesheet">

<!-- css hamburger -->
<link href="<?= base_url() . 'assets/login/vendor/css-hamburger/hamburger.css' ?>" rel="stylesheet">
<link href="<?= base_url() . 'assets/login/vendor/css-hamburger/hamburger.min.css' ?>" rel="stylesheet">

<!-- daterangepicker -->
<link href="<?= base_url() . 'assets/login/vendor/daterangepicker/daterangepicker.css' ?>" rel="stylesheet">
<link href="<?= base_url() . 'assets/login/vendor/daterangepicker/daterangepicker.js' ?>" rel="stylesheet">
<link href="<?= base_url() . 'assets/login/vendor/daterangepicker/moment.js' ?>" rel="stylesheet">
<link href="<?= base_url() . 'assets/login/vendor/daterangepicker/moment.min.js' ?>" rel="stylesheet">

<!-- jquery -->
<link href="<?= base_url() . 'assets/login/vendor/jquery/jquery-3.2.1.min.js' ?>" rel="stylesheet">

<!-- perfect scrollbar -->
<link href="<?= base_url() . 'assets/login/vendor/perfect-scrollbar/perfect-scrollbar.css' ?>" rel="stylesheet">

<!-- select -->
<link href="<?= base_url() . 'assets/login/vendor/select2/select2.css' ?>" rel="stylesheet">
<link href="<?= base_url() . 'assets/login/vendor/select2/select2.js' ?>" rel="stylesheet">
<link href="<?= base_url() . 'assets/login/vendor/select2/select2.min.css' ?>" rel="stylesheet">
<link href="<?= base_url() . 'assets/login/vendor/select2/select2.min.js' ?>" rel="stylesheet">

<link href="<?= base_url() . 'assets/login/images/bg-01.jpg' ?>" rel="stylesheet">
<nav class="navbar-expand-lg" style="background-color: #8ACDD7; padding: 10px;">
<center>
        <p>&copy; Sasika 2023. All rights reserved.</p>
       
    </center>
    
</nav>
